package com.cdu.community.server.charge.infrastructure.orm;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cdu.community.server.charge.domain.entity.ChargeProject;

/**
 * @author mila
 * @date 2024/6/14 下午3:18
 */
public interface ChargeProjectMapper extends BaseMapper<ChargeProject> {

}
