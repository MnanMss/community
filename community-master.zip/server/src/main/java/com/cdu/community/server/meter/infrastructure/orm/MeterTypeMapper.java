package com.cdu.community.server.meter.infrastructure.orm;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cdu.community.server.meter.domain.entity.MeterType;

/**
 * @author mila
 * @date 2024/6/14 下午2:57
 */
public interface MeterTypeMapper extends BaseMapper<MeterType> {

}
